.. SPDX-FileCopyrightText: 2013 Ole Martin Bjorndalen <ombdalen@gmail.com>
.. SPDX-FileCopyrightText: 2023 Raphaël Doursenaud <rdoursenaud@gmail.com>
..
.. SPDX-License-Identifier: CC-BY-4.0

Authors
=======

Ole Martin Bjørndalen (lead programmer), Raphaël Doursenaud (co-maintainer) and
many other contributors.

Many people have contributed to Mido over the years, but this page has
not been updated to include them. The :doc:`/changes` page
includes names of all contributors.

.. seealso::

    https://github.com/mido/mido/graphs/contributors
