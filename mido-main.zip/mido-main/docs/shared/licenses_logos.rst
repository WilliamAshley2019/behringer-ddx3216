.. SPDX-FileCopyrightText: 2023 Raphaël Doursenaud <rdoursenaud@gmail.com>
..
.. SPDX-License-Identifier: CC-BY-4.0


.. |Creative Commons BY-4.0 License| image::
   https://licensebuttons.net/l/by/4.0/88x31.png
   :target: https://creativecommons.org/licenses/by/4.0/

.. |Creative Commons BY-SA-3.0 License| image::
    https://licensebuttons.net/l/by-sa/3.0/88x31.png
   :target: https://creativecommons.org/licenses/by-sa/3.0/

.. |Creative Commons CC0-1.0 License| image::
    https://licensebuttons.net/p/zero/1.0/88x31.png
   :target: https://creativecommons.org/publicdomain/zero/1.0/
